/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.distributed.hadoop;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text, Text, Text, Text> {
    private Text result = new Text();
    @Override
    public void reduce(Text key, Iterable<Text> values,
                       Context context
                       ) throws IOException, InterruptedException {
        
        //This array list contains a set of friends.
        //For example if our input is ("Adam Aris", list of Adam's friends) and ("Adam Aris", list of Aris's friends)
        //then this array list contains the two friend lists, contained in a HashSet.
        
        System.out.println("Reducer Input: ");
        System.out.println("\t "+key);
        
        ArrayList<HashSet<String>> friendSets = new ArrayList<>();
        
        //There are always two Texts each containing a list of friends, 
        //but this is a more generic approach
        for (Text val : values) {
            friendSets.add(stringToSet(val.toString()));
            System.out.println("\t "+val);
        }
        
        //A set containing the common friends between the two users, and is initialized
        //to the first list of friends
        HashSet<String> commonFriends = new HashSet(friendSets.get(0));

        //This is a loop from i = 1 to i = 2, it executes only once, 
        //used for a more generic approach, as above.
        //This intersects the two sets and keeps the common friends
        for (int i = 1; i < friendSets.size(); i++) {
            commonFriends.retainAll(friendSets.get(i));
        }

        //We don't know yet whose list is which, because they both arrive with the same key.
        //So the list of say Adam, is the list that does not contain his name, as the other list is 
        //the list of his friend's friends. 
        //We store the name of each user and find out which list is which. We assume that the list of the 
        //first user is the first list, and the second user's list is the second, and change it if its the opposite.
        String friends = key.toString();
        String friendA = friends.split(",")[0];
        String friendB = friends.split(",")[1];

        int indexA = 0;
        int indexB = 1;

        if (friendSets.get(0).contains(friendA)) {
            indexB = 0;
        }
        if (friendSets.get(1).contains(friendB)) {
            indexA = 1;
        }

        //If the number of common friends is larger or equal to 5, then suggest the uncommon friends to each other.
        if (commonFriends.size() >= 5) {
            HashSet<String> suggestToA = friendSets.get(indexB);
            suggestToA.removeAll(commonFriends);
            HashSet<String> suggestToB = friendSets.get(indexA);
            suggestToB.removeAll(commonFriends);
            System.out.println("\tIndices: "+indexA + " " + indexB);
            System.out.println("\tCommon friends: "+commonFriends);
            //Outputting suggestions
            for (String s : suggestToA) {
                //This if disallows the suggestion someone's self.
                //For example, Aris is friends with Adam, and ofcourse Adam is not on Adam's friend list, so he
                //shows up as an uncommon friend. Same goes for the other user.
                if (!friendA.equals(s)) {
                    System.out.println("\tSuggesting: "+friendA+" "+s);
                    context.write(new Text(friendA), new Text(s));
                }
            }

            for (String s : suggestToB) {
                if (!friendB.equals(s)) {
                    System.out.println("\tSuggesting: "+friendB+" "+s);
                    context.write(new Text(friendB), new Text(s));
                }
            }
        }
    }

    public static HashSet<String> stringToSet(String friendsString) {
        //Converts a string to a set. The string describes a list where the entries
        //are seperated by commas.
        
        String[] friends = friendsString.split(",");
        HashSet<String> frSet = new HashSet<>();
        for (int i = 0; i < friends.length; i++) {
            frSet.add(friends[i]);
        }
        return frSet;
    }

}
