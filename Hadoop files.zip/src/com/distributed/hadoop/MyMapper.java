/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.distributed.hadoop;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<Object, Text, Text, Text> {

    private final static Text friends = new Text();

    public void map(Object key, Text value, Mapper.Context context
    ) throws IOException, InterruptedException {
        System.out.println("Mapper input:");
        System.out.println("\tValue: "+value);
        //Mapper accepts a username and a list of friends (in string format)
        //So an example input could be Adam Aris, George
        //Adam is the user, and his friends are Aris and George
        String[] keyPair = value.toString().split(" ");
        String name_str = keyPair[0]; //Username
        String ff = new String(); //List of friends
        
        //Get list of friends. First string in "keyPair" is the username, so we ignore it.
        //This loop will never get out of bounds, as for a user to be listed in our input file, he must have at least one friend.
        //So they keyPair array has at least a size of 2.
        for(int i = 1; i < keyPair.length; i++) {
            ff = ff.concat(keyPair[i]);
        }
        
        friends.set(ff);
        
        //Split friend list by "," to get each friend's name
        String[] split = ff.split(",");
        
        //Now for each friend, we make a string named "duo" that contains the user's name and that friend's name.
        //For our example input mentioned above, we would have a "Adam Aris" and a "Adam George" duo.
        //This mapper outputs a duo and the friends of one of the duo's members.
        //Example output: ("Adam Aris", list of adam's friends), ("Adam George", list of adam's friends).
        //When we encounter Aris in our file we do the same. So the reducer receives the following:
        //("Adam Aris", list of Adam's friends), ("Adam Aris", list of Aris's friends) and then we can suggest friends
        //to each other.
        for (String s : split) {
            Text duo = new Text();
            if (name_str.compareTo(s) > 0) {
                duo.set(s + "," + name_str);
            } else {
                duo.set(name_str + "," + s);
            }
            System.out.println("\tMapper output:");
            System.out.println("\t\tDuo: "+duo+" friends: "+friends);
            context.write(duo, friends);
        }
    }
}
